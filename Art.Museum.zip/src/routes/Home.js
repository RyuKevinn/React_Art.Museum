import React ,{useState} from 'react';
import styled from 'styled-components'
import cn from 'classnames'

const HomeBlock = styled.div`
position:relative;
.logo{
    position:fixed;
    top:0;
    left:0;
    font-size:30px;
    z-index:9999;
    color:white;
    font-size: 60px;
    padding: 30px 50px;
}
.box_3d{
    width:100vw;
    height:100vh;
    position:relative;
    perspective: 1000px;
    background-image:url(img/museum-gba021b009_1920.jpg);
    background-position: center bottom;
    background-size:cover;
    .cube{
        &.movefront{transform:rotateX(-10deg) rotateY(0deg) translate(0)}
        &.moveback{transform:rotateX(-10deg) rotateY(180deg);}
        &.moveleft{transform:rotateX(-10deg) rotateY(90deg);}
        &.moveright{transform:rotateX(-10deg) rotateY(-90deg);}
        &.movetop{transform:rotateX(-100deg) rotateY(0deg);}
        &.movebottom{transform:rotateX(80deg) rotateY(0deg);}
        transform:rotateX(-1deg) rotateY(32deg) translate3d(-100px ,200px,-2850px);
        position:absolute;
        top:10%;
        left:50%;
        width:500px;
        height:500px;
        transform-style: preserve-3d;
        transition: all 3s;
        transform-origin: 50% 50% -250px;
        .front{background:black;}
        .back{  transform:rotateY(180deg) translateZ(500px);}
        .left{  transform:rotateY(-90deg) translateX(-500px); transform-origin: left;}
        .right{ transform:rotateY(90deg)  translateX(500px);  transform-origin: right;}
        .top{   transform:rotateX(90deg)  translateY(-500px); transform-origin: top;}
        .bottom{transform:rotateX(-90deg) translateY(500px);  transform-origin: bottom;}
        .cube_side{
            position:absolute;
            top:0;
            left:0;
            width:100%;
            height:100%;
            display:flex;
            justify-content: center;
            align-items:center;
            flex-direction: column;
            font-size:45px;
            background:black;
            color:white;
            h1{
                transform:translateZ(50px);
                font-size: 50px;
                position:absolute;
                top:30px;
            }
            img{
                width:100%;
                position:absolute;
                bottom:0;
            }
        }
    }
    .btn{
        width:100%;
        font-size:30px;
        position:absolute;
        bottom:0%;
        left:0%;
        text-align: center;
        z-index:4; 
        button{
            border-top-left-radius: 10px;
            border-top-right-radius: 10px;
            background: none;
            color:white;
            border:none;
            border-bottom:2px solid white;
            width:100px;
            font-size:35px;
            margin: 0 10px 50px;
            cursor: pointer;
            padding-bottom: 5px;
            transition: all 0.4s;
            &:hover{
                background: rgba(255,255,255,0.2);
            }
        }
    }
}
.ment_box{
    position:absolute;
    top:50%;
    transform:translateY(-50%);
    left:10vw;;
    width:500px;
    height: 70vh;
    background:rgba(0,0,0,0.4);
    border-radius:30px;
    .ment{
        color:white;
        position:absolute;
        top:50%;
        left:0;
        transform:translateY(-50%);
        width:100%;
        height:100%;
        opacity:0;
        transition: 3s;
        h2{
            font-family: 'Grape Nuts', cursive;
            text-align:center;
            padding-top: 3vh;
            font-size:50px;
        }
        span{
            font-family: 'Grape Nuts', cursive;
            font-size:30px;
            display:block;
            text-align: center;
            padding: 20px 0;
        }
        p {
            font-family: 'Grape Nuts', cursive;
            font-size: 2.5vh;
            overflow-wrap: break-word;
            word-break: keep-all;
            padding:0 30px;
            line-height: 4.2vh;
        }
        &.now{
            opacity:1;
        }
    }
}

`;

const Home = () => {

    const [movefront,setMoveFront]=useState(false);
    const mfront = ()=>{
        setMoveFront(true)
        setMoveBack(false)
        setMoveLeft(false)
        setMoveRight(false)
        setMoveTop(false)
        setMoveBottom(false)
    }

    const [moveback,setMoveBack]=useState(false);
    const mback = ()=>{
        setMoveFront(false)
        setMoveBack(true)
        setMoveLeft(false)
        setMoveRight(false)
        setMoveTop(false)
        setMoveBottom(false)
    }

    const [moveleft,setMoveLeft]=useState(false);
    const mleft = ()=>{
        setMoveFront(false)
        setMoveBack(false)
        setMoveLeft(true)
        setMoveRight(false)
        setMoveTop(false)
        setMoveBottom(false)
    }

    const [moveright,setMoveRight]=useState(false);
    const mright = ()=>{
        setMoveFront(false)
        setMoveBack(false)
        setMoveLeft(false)
        setMoveRight(true)
        setMoveTop(false)
        setMoveBottom(false)
    }

    const [movetop,setMoveTop]=useState(false);
    const mtop = ()=>{
        setMoveFront(false)
        setMoveBack(false)
        setMoveLeft(false)
        setMoveRight(false)
        setMoveTop(true)
        setMoveBottom(false)
    }

    const [movebottom,setMoveBottom]=useState(false);
    const mbottom = ()=>{
        setMoveFront(false)
        setMoveBack(false)
        setMoveLeft(false)
        setMoveRight(false)
        setMoveTop(false)
        setMoveBottom(true)
    }


    return (
        <HomeBlock>
            <h1 className='logo'>Art Museum</h1>
            <div className="box_3d">
        <div className={cn('cube',{movefront},{moveback},{moveright},{moveleft},{movetop},{movebottom})}>
            <div className="cube_side front">
                <h1>Vincent Van Gohg</h1>
                <img src="img/vincent.png" alt=""/>
            </div>
            <div className="cube_side back">
                <h1>Monet</h1>
                <img src="img/monet.jpg" alt=""/>
            </div>
            <div className="cube_side left">
                <h1>Gauguin</h1>
                <img src="img/gauguin.jpg" alt=""/>
            </div>
            <div className="cube_side right">
                <h1>Picasso</h1>
                <img src="img/picasso.jpg" alt=""/>
            </div>
            <div className="cube_side top">
                <h1>Edvard Munch</h1>
                <img src="img/Munch.png" alt=""/>
            </div>
            <div className="cube_side bottom">
                <h1>Jean François Millet</h1>
                <img src="img/Millet.jpg" alt=""/>
            </div>
        </div>
        <div className="btn">
            <button className="move_front" onClick={mfront}>Picece 1</button>
            <button className="move_back" onClick={mback}>Picece 2 </button>
            <button className="move_bottom" onClick={mbottom}>Picece 3</button>
            <button className="move_left" onClick={mleft}>Picece 4</button>
            <button className="move_top" onClick={mtop}>Picece 5</button>
            <button className="move_right" onClick={mright}>Picece 6</button>
        </div>
    </div>
    <div className="ment_box">
        <div className='ment fr' style={{opacity: movefront ? 1 : 0}}>
            <h2>Vincent Van Gohg</h2>
            <span>1853 - 1890</span>
            <p>a Dutch post-impressionist painter Although it was a short life, he remains the most famous artist. Early works were works of dark shades, and later works showed a tendency of expressionism. Gogh's work provided the foundation for the development of the 20th century art movements of Beastism and German Expressionism.
            </p>
        </div>
        <div className="ment bk" style={{opacity: moveback ? 1 : 0}}>
            <h2>Oscar-Claude Monet</h2>
            <span>1840 - 1926</span>
            <p>a French impressionist One of the founders of the Impressionist style, the word 'impressionism' arose from his work, 'Impressionism, Sunrise.' He adhered to the impressionistic principle of 'light is color,'' and explored how the same thing changes according to light through a series of works. The series of 'Training' in its later years is regarded as a great masterpiece that showed a cosmic view of nature.</p>
        </div>
        <div className="ment lft" style={{opacity: moveleft ? 1 : 0}}>
            <h2>Eugène Henri Paul Gauguin</h2>
            <span>1848 - 1903</span>
            <p>a French post-impressionist painter He left for Tahiti Island in the South Pacific out of disgust for the civilized world, and the healthy humanity of the natives and the bright and intense colors of the tropics completed his art. His symbolism, inner nature, and non-naturalistic tendencies played a fundamental role in the emergence of 20th century paintings.</p>
        </div>
        <div className="ment rht" style={{opacity: moveright ? 1 : 0}}>
            <h2>Pablo Ruiz y Picasso</h2>
            <span>1881 - 1973</span>
            <p>a Spanish-born cubist painter active in France Influenced by French art, he moved to Paris and was influenced by masters such as Renoir, Toulouse, Munch, Gauguin, and Gogh. After the early blue era, he created a three-dimensional art style and became the greatest master of the 20th century. Works such as "Gernica" and "Maiden of Avignon" are famous.</p>
        </div>
        <div className="ment tp" style={{opacity: movetop ? 1 : 0}}>
            <h2>Edvard Munch</h2>
            <span>1863 - 1944</span>
            <p>a Norwegian painter Munch, who was suffering from mental illness, had emotional problems, but worked on the anxious painting with detailed planning. The Scream is a representative work that embodies the pain of existence. After a nervous breakdown, the work became more optimistic, mainly painting natural landscapes.</p>
        </div>
        <div className="ment btm" style={{opacity: movebottom ? 1 : 0}}>
            <h2>Jean François Millet</h2>
            <span>1814 - 1875</span>
            <p>a French painter By producing a series of works covered in peasant life with a serious attitude, he established a unique poetic sentiment and a style of writing with an excellent atmosphere, and became a representative painter of the Barbi sect. However, unlike other artists, he painted more peasant life than landscape. Major works include Seed Sowers, Gleaners, and Manjong.</p>
        </div>
    </div>
        </HomeBlock>
    );
};

export default Home;